fetch(url, {
    method:"POST",
    body: JSON.stringify({
        name: msg,
        Email: email,
        pass: password,
        copass: copassword
        })
    }).then(result => {
        result = window.open("file:///E:/lessons/JS/project/home.html");
        console.log("Completed with result:", result);
    }).catch(err => {
        err = eror;
        console.error(err);
    });